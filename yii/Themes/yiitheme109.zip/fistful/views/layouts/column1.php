<?php $this->beginContent('//layouts/main'); ?>
<div class="art-content-layout">
    <div class="art-content-layout-row">
        <div class="art-layout-cell layout-item-0" style="width: 100%;">
            <?php echo $content; ?>
        </div>
    </div>
</div>
<?php $this->endContent(); ?>
